const ulList = ["+", "-", "*", "/"];

const array = Array.from({ length: 10 }, (_, i) => i);

export { ulList, array };
