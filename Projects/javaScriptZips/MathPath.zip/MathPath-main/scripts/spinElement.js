const spinElement = (ele) => {
  ele.classList.add("spinOnce");
};

export { spinElement };
