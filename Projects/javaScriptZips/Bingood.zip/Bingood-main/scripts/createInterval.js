const createInterval = (ele, value) => {
  ele.innerHTML = `<span class="max-w-screen-md">${value}</span>`;
};

export default createInterval;
