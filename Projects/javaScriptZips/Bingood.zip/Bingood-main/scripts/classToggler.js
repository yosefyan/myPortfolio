const classToggler = (ele, theClass) => {
  return ele && ele.classList.toggle(theClass);
};

export default classToggler;
