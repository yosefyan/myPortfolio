let arr = Array(6).fill("");

export default arr;
