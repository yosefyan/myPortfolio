const clearTypedOne = (array) => {
  return array.pop();
};

export default clearTypedOne