const removeElement =(ele) => {
   return ele.remove();
}

export default removeElement;