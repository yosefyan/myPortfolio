const reset = (container) => {
  container.innerHTML = '';
}

export default reset;