# PurrfectRecall - Cat-Themed Memory Game

Enjoy PurrfectRecall, a memory game featuring adorable cat photos. Challenge your memory with 2-100 cards, but beware—your chosen amount doubles! For example, select 50 cards, face 100. Test your memory skills with charming cats for a PurrfectRecall!

## How to Play

1. Access PurrfectRecall: [Play Now](https://yosefyan.github.io/purrfectrecall).

2. Choose the number of cards (2-100).

3. Memorize and match adorable cat photos.

4. Be mindful—the chosen card amount doubles for an added challenge!

5. Strive for a PurrfectRecall and enjoy the delightful cat-themed experience.

## Technologies Used

- HTML
- CSS
- JavaScript
