let completedArray = [];

const btnsArray = ["HOME", "RESTART"];

const victoryBtnsArray = ['PLAY AGAIN', 'CLOSE']

export { completedArray, btnsArray, victoryBtnsArray };
