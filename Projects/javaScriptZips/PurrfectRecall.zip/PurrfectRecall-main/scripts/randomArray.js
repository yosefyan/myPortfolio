const randomArray = (array) => {
  return array.sort(() => Math.random() - 0.2);
};

export default randomArray;
